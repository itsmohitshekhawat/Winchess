import chess
import subprocess


def get_stockfish_move(
    board,
    stockfish_path="stockfish\\stockfish-windows-x86-64-avx2.exe",
):
    fen = board.fen()
    command = [stockfish_path]

    # Start Stockfish as a subprocess
    engine = subprocess.Popen(
        command,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        universal_newlines=True,
    )

    # Send the FEN position to Stockfish
    engine.stdin.write(f"position fen {fen}\n")
    engine.stdin.write("go depth 20\n")  # Adjust the depth as needed
    engine.stdin.flush()

    # Read Stockfish's best move
    best_move = ""
    while True:
        line = engine.stdout.readline().strip()
        if line.startswith("bestmove"):
            best_move = line.split()[1]
            break

    # Close the subprocess
    engine.terminate()

    return best_move


def main():
    board = chess.Board()
    print(
        "Hello, Welcome to WinChess - Developed by Mohit Shekhawat (Youtube: @itsmohitshekhawat)"
    )
    # Ask the user for their color choice
    user_color = input("Choose your color (white or black): ").lower()
    if user_color == "white":
        user_turn = True
        print("You start the game.")
        print("Block names from your view: a to h")
    elif user_color == "black":
        user_turn = False
        print("Your opponent starts the game.")
        print("Block names from your view: h to a")
    else:
        print("Invalid color choice. Please choose white or black.")
        return

    while not board.is_game_over():
        print(board)

        if user_turn:
            # Stockfish AI suggests the user's move
            ai_move = get_stockfish_move(board)
            print(f"Suggested move for you: {ai_move}")
            board.push(chess.Move.from_uci(ai_move))
        else:
            if user_color == "white":
                user_move = input("Enter your move (e.g., a2a4): ")
            else:
                user_move = input("Enter your opponent's move (e.g., h7h5): ")
            if chess.Move.from_uci(user_move) in board.legal_moves:
                board.push(chess.Move.from_uci(user_move))
            else:
                print("Invalid move. Try again.")
                continue

        user_turn = not user_turn

    # Game over
    print("Game over. Result: " + board.result())


if __name__ == "__main__":
    main()
